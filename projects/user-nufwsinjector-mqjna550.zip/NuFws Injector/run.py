"""Atalho: python run.py"""
from nuflow.main import main

if __name__ == "__main__":
    raise SystemExit(main())
