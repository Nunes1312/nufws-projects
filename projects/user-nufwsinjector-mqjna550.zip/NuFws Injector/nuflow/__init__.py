"""NuFlow — hiperautomação e orquestração de processos (RPA + IA)."""
__version__ = "0.1.0"
