"""UI do NuFlow (PyQt6)."""
