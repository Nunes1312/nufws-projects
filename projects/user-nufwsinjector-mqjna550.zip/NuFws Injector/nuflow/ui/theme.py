"""Tema escuro do NuFlow (acento teal, distinto do NuFws violeta)."""
P = {
    "bg": "#0d1117", "sidebar": "#11161d", "surface": "#161b22", "surface2": "#1c232c",
    "border": "#262d38", "text": "#e6edf3", "muted": "#8b949e", "faint": "#5b636e",
    "accent": "#17b6a7", "accent_hi": "#1fd3c1", "ok": "#3fb950", "warn": "#d29922",
    "bad": "#f85149",
}


def qss() -> str:
    p = P
    return f"""
* {{ font-family:'Segoe UI',sans-serif; font-size:13px; color:{p['text']}; }}
QMainWindow,QWidget {{ background:{p['bg']}; }}
QTabWidget::pane {{ border:1px solid {p['border']}; border-radius:8px; top:-1px; }}
QTabBar::tab {{ background:transparent; color:{p['muted']}; padding:9px 18px; border:none; }}
QTabBar::tab:selected {{ color:{p['text']}; border-bottom:2px solid {p['accent']}; }}
QTabBar::tab:hover {{ color:{p['text']}; }}
QLabel#title {{ font-size:20px; font-weight:700; }}
QLabel#sub {{ color:{p['muted']}; }}
QLabel#ok {{ color:{p['ok']}; font-weight:600; }}
QLabel#bad {{ color:{p['bad']}; font-weight:600; }}
QLabel#metric {{ font-size:22px; font-weight:700; color:{p['accent_hi']}; }}
QPushButton {{ background:{p['accent']}; color:#04201d; border:none; padding:8px 16px;
    border-radius:8px; font-weight:700; }}
QPushButton:hover {{ background:{p['accent_hi']}; }}
QPushButton:disabled {{ background:{p['surface2']}; color:{p['faint']}; }}
QPushButton#secondary {{ background:{p['surface2']}; color:{p['text']};
    border:1px solid {p['border']}; }}
QPushButton#secondary:hover {{ border-color:{p['accent']}; }}
QLineEdit,QComboBox,QPlainTextEdit,QSpinBox {{ background:{p['surface']};
    border:1px solid {p['border']}; border-radius:8px; padding:7px 10px; }}
QLineEdit:focus,QComboBox:focus {{ border-color:{p['accent']}; }}
QFrame#card {{ background:{p['surface']}; border:1px solid {p['border']}; border-radius:12px; }}
QTableWidget {{ background:{p['surface']}; gridline-color:{p['border']};
    border:1px solid {p['border']}; border-radius:8px; selection-background-color:{p['surface2']}; }}
QHeaderView::section {{ background:{p['surface2']}; color:{p['muted']}; padding:7px;
    border:none; border-bottom:1px solid {p['border']}; font-weight:600; }}
QPlainTextEdit#console {{ font-family:'Consolas',monospace; background:#080b10;
    border:1px solid {p['border']}; border-radius:8px; }}
QStatusBar {{ background:{p['sidebar']}; color:{p['muted']}; }}
QScrollBar:vertical {{ background:transparent; width:11px; }}
QScrollBar::handle:vertical {{ background:{p['border']}; border-radius:5px; min-height:24px; }}
"""
