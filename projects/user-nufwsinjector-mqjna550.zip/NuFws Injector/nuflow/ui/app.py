"""NuFlow — janela principal (Fluxos, Documentos IDP, Cofre)."""
from __future__ import annotations

import json
import os

from PyQt6.QtCore import QObject, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor
from PyQt6.QtWidgets import (
    QAbstractItemView, QComboBox, QFileDialog, QFormLayout, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMainWindow, QPlainTextEdit, QPushButton,
    QSplitter, QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from ..core import Flow, load_flow, make_runner
from ..core import vault
from .theme import P

_LV = {"INFO": P["muted"], "SUCESSO": P["ok"], "AVISO": P["warn"], "ERRO": P["bad"]}


class FlowThread(QThread):
    line = pyqtSignal(str, str)
    step = pyqtSignal(object)
    done = pyqtSignal(object)

    def __init__(self, flow: Flow):
        super().__init__()
        self.flow = flow

    def run(self):
        runner = make_runner(log=lambda lvl, m: self.line.emit(lvl, m),
                             step_cb=lambda sr: self.step.emit(sr))
        self.done.emit(runner.run(self.flow))


class _Job(QObject):
    done = pyqtSignal(object)
    fail = pyqtSignal(str)


class FlowsTab(QWidget):
    def __init__(self):
        super().__init__()
        self._thread: FlowThread | None = None
        self._runs = 0
        self._steps_ok = 0
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Fluxo:"))
        self.path = QLineEdit(); self.path.setPlaceholderText("selecione um .json de fluxo")
        top.addWidget(self.path, 1)
        b = QPushButton("…"); b.setObjectName("secondary"); b.setFixedWidth(36)
        b.clicked.connect(self._browse); top.addWidget(b)
        top.addWidget(QLabel("dir:"))
        self.dirvar = QLineEdit(); self.dirvar.setMaximumWidth(220)
        self.dirvar.setPlaceholderText("override de {{dir}} (opcional)")
        top.addWidget(self.dirvar)
        self.run_btn = QPushButton("Executar"); self.run_btn.clicked.connect(self._run)
        top.addWidget(self.run_btn)
        root.addLayout(top)

        # dashboard
        dash = QHBoxLayout()
        for key, lbl in [("runs", "Execuções"), ("ok", "Steps ok"), ("saved", "Horas poupadas (est.)")]:
            card = QFrame(); card.setObjectName("card")
            cl = QVBoxLayout(card)
            m = QLabel("0"); m.setObjectName("metric"); setattr(self, f"m_{key}", m)
            cl.addWidget(m)
            t = QLabel(lbl); t.setObjectName("sub"); cl.addWidget(t)
            dash.addWidget(card)
        root.addLayout(dash)

        split = QSplitter(Qt.Orientation.Horizontal)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["#", "Passo", "Status", "ms"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        split.addWidget(self.table)
        self.console = QPlainTextEdit(); self.console.setReadOnly(True)
        self.console.setObjectName("console")
        split.addWidget(self.console)
        split.setSizes([360, 520])
        root.addWidget(split, 1)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Fluxo", "", "JSON (*.json)")
        if p:
            self.path.setText(p)
            self.dirvar.setText(os.path.dirname(p))

    def _run(self):
        path = self.path.text().strip()
        if not os.path.isfile(path):
            self._log("ERRO", "selecione um arquivo de fluxo válido")
            return
        try:
            flow = load_flow(path)
        except Exception as e:  # noqa: BLE001
            self._log("ERRO", f"falha ao ler fluxo: {e}")
            return
        if self.dirvar.text().strip():
            flow.vars["dir"] = self.dirvar.text().strip()
        self.console.clear(); self.table.setRowCount(0)
        self.run_btn.setEnabled(False)
        self._thread = FlowThread(flow)
        self._thread.line.connect(self._log)
        self._thread.step.connect(self._on_step)
        self._thread.done.connect(self._on_done)
        self._thread.start()

    def _on_step(self, sr):
        r = self.table.rowCount(); self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(str(sr.index + 1)))
        self.table.setItem(r, 1, QTableWidgetItem(sr.id or sr.action))
        mark = {"ok": "✓ ok", "erro": "✗ erro", "pulado": "– pulado"}.get(sr.status, sr.status)
        self.table.setItem(r, 2, QTableWidgetItem(mark))
        self.table.setItem(r, 3, QTableWidgetItem(str(sr.duration_ms)))
        if sr.status == "ok":
            self._steps_ok += 1

    def _on_done(self, res):
        self.run_btn.setEnabled(True)
        self._runs += 1
        self.m_runs.setText(str(self._runs))
        self.m_ok.setText(str(self._steps_ok))
        # estimativa ingênua: 2 min poupados por step ok
        self.m_saved.setText(f"{self._steps_ok * 2 / 60:.1f}")

    def _log(self, level, msg):
        color = _LV.get(level, P["text"])
        self.console.appendHtml(f'<span style="color:{color}">[{level}]</span> '
                                f'<span style="color:{P["text"]}">{msg}</span>')
        self.console.moveCursor(QTextCursor.MoveOperation.End)


class IdpTab(QWidget):
    def __init__(self):
        super().__init__()
        self._job = _Job()
        self._job.done.connect(self._on_done)
        self._job.fail.connect(lambda m: self._set(m))
        self._thr: QThread | None = None
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.addWidget(QLabel("Leitura inteligente de documentos (Claude)"))
        sub = QLabel("Solte um PDF/imagem e os campos a extrair. Requer ANTHROPIC_API_KEY.")
        sub.setObjectName("sub"); root.addWidget(sub)
        form = QFormLayout()
        row = QHBoxLayout()
        self.doc = QLineEdit(); row.addWidget(self.doc, 1)
        b = QPushButton("…"); b.setObjectName("secondary"); b.setFixedWidth(36)
        b.clicked.connect(self._browse); row.addWidget(b)
        form.addRow("Documento:", row)
        self.fields = QLineEdit(); self.fields.setPlaceholderText("ex.: numero, data, valor_total, fornecedor")
        form.addRow("Campos:", self.fields)
        self.key = QLineEdit(); self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("vazio = usa ANTHROPIC_API_KEY do ambiente")
        form.addRow("API key:", self.key)
        root.addLayout(form)
        self.run_btn = QPushButton("Extrair"); self.run_btn.clicked.connect(self._run)
        root.addWidget(self.run_btn)
        self.out = QPlainTextEdit(); self.out.setReadOnly(True); self.out.setObjectName("console")
        root.addWidget(self.out, 1)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Documento", "",
                                           "Documentos (*.pdf *.png *.jpg *.jpeg)")
        if p:
            self.doc.setText(p)

    def _run(self):
        from ..core.idp import extract_document
        path = self.doc.text().strip()
        if not os.path.isfile(path):
            self._set("selecione um documento válido"); return
        fields = [f.strip() for f in self.fields.text().split(",") if f.strip()]
        key = self.key.text().strip() or None
        self.run_btn.setEnabled(False); self.out.setPlainText("consultando Claude…")

        class T(QThread):
            def run(self_):
                try:
                    self._job.done.emit(extract_document(path, fields, api_key=key))
                except Exception as e:  # noqa: BLE001
                    self._job.fail.emit(f"{type(e).__name__}: {e}")
        self._thr = T(); self._thr.start()

    def _on_done(self, data):
        self.run_btn.setEnabled(True)
        self.out.setPlainText(json.dumps(data, ensure_ascii=False, indent=2))

    def _set(self, msg):
        self.run_btn.setEnabled(True); self.out.setPlainText(msg)


class VaultTab(QWidget):
    def __init__(self):
        super().__init__()
        self._build(); self._refresh()

    def _build(self):
        root = QVBoxLayout(self)
        root.addWidget(QLabel("Cofre de credenciais (DPAPI)"))
        sub = QLabel("Segredos de sistemas legados, criptografados por usuário (Windows DPAPI).")
        sub.setObjectName("sub"); root.addWidget(sub)
        row = QHBoxLayout()
        self.name = QLineEdit(); self.name.setPlaceholderText("nome (ex.: erp_senha)")
        row.addWidget(self.name)
        self.value = QLineEdit(); self.value.setEchoMode(QLineEdit.EchoMode.Password)
        self.value.setPlaceholderText("valor")
        row.addWidget(self.value, 1)
        add = QPushButton("Salvar"); add.clicked.connect(self._add); row.addWidget(add)
        root.addLayout(row)
        self.list = QTableWidget(0, 1); self.list.setHorizontalHeaderLabels(["Segredos guardados"])
        self.list.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.list.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.list.verticalHeader().setVisible(False)
        root.addWidget(self.list, 1)

    def _add(self):
        if self.name.text().strip() and self.value.text():
            vault.set_secret(self.name.text().strip(), self.value.text())
            self.name.clear(); self.value.clear(); self._refresh()

    def _refresh(self):
        names = vault.list_secrets()
        self.list.setRowCount(len(names))
        for r, n in enumerate(names):
            self.list.setItem(r, 0, QTableWidgetItem(n))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NuFlow — Hiperautomação & Orquestração")
        self.resize(1160, 760)
        tabs = QTabWidget()
        tabs.addTab(FlowsTab(), "Fluxos")
        tabs.addTab(IdpTab(), "Documentos (IDP)")
        tabs.addTab(VaultTab(), "Cofre")
        self.setCentralWidget(tabs)
        self.statusBar().showMessage("NuFlow 0.1 — RPA + IA · automação de UI via step ui_action")
