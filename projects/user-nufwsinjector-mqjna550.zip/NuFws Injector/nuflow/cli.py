"""
NuFlow — runner de linha de comando (para agendamento/CI/execução não-assistida).

  python -m nuflow.cli <fluxo.json> [--dir CAMINHO] [--set chave=valor ...]

Sai com código 0 se o fluxo terminou ok, 1 se houve erro — útil como gate de CI
ou tarefa agendada (Agendador de Tarefas do Windows).
"""
from __future__ import annotations

import argparse
import sys

from .core import load_flow, make_runner


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="nuflow", description="Executa um fluxo NuFlow.")
    ap.add_argument("flow", help="caminho do .json de fluxo")
    ap.add_argument("--dir", help="override da variável {{dir}}")
    ap.add_argument("--set", action="append", default=[], metavar="K=V",
                    help="define variável de contexto (repetível)")
    args = ap.parse_args(argv)

    flow = load_flow(args.flow)
    if args.dir:
        flow.vars["dir"] = args.dir
    ctx = {}
    for kv in args.set:
        if "=" in kv:
            k, v = kv.split("=", 1)
            ctx[k.strip()] = v
    res = make_runner().run(flow, ctx)
    return 0 if res.status == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
