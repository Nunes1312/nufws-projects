"""NuFlow — entrypoint da UI."""
from __future__ import annotations

import sys

from PyQt6.QtWidgets import QApplication

from .ui.theme import qss
from .ui.app import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("NuFlow")
    app.setStyleSheet(qss())
    win = MainWindow()
    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
