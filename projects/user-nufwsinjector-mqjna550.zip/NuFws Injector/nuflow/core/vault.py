"""
NuFlow — cofre de credenciais (Windows DPAPI).

Guarda segredos de sistemas legados (usuário/senha/tokens) criptografados por
usuário via CryptProtectData, num JSON em %APPDATA%/NuFlow/vault.json.
Nenhum segredo fica em texto puro em disco.
"""
from __future__ import annotations

import base64
import ctypes
import json
import os
from ctypes import wintypes

_crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
CRYPTPROTECT_UI_FORBIDDEN = 0x01


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


for _fn in (_crypt32.CryptProtectData, _crypt32.CryptUnprotectData):
    _fn.argtypes = [ctypes.POINTER(_BLOB), wintypes.LPCWSTR, ctypes.POINTER(_BLOB),
                    ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD,
                    ctypes.POINTER(_BLOB)]
    _fn.restype = wintypes.BOOL
_kernel32.LocalFree.argtypes = [ctypes.c_void_p]


def _blob(data: bytes) -> _BLOB:
    buf = ctypes.create_string_buffer(data, len(data))
    return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _encrypt(text: str) -> str:
    inp, out = _blob(text.encode("utf-8")), _BLOB()
    if not _crypt32.CryptProtectData(ctypes.byref(inp), "NuFlow", None, None, None,
                                     CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
        raise OSError("CryptProtectData falhou")
    try:
        return base64.b64encode(ctypes.string_at(out.pbData, out.cbData)).decode()
    finally:
        _kernel32.LocalFree(out.pbData)


def _decrypt(b64: str) -> str:
    try:
        raw = base64.b64decode(b64)
    except Exception:
        return ""
    inp, out = _blob(raw), _BLOB()
    if not _crypt32.CryptUnprotectData(ctypes.byref(inp), None, None, None, None,
                                       CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
        return ""
    try:
        return ctypes.string_at(out.pbData, out.cbData).decode("utf-8", "replace")
    finally:
        _kernel32.LocalFree(out.pbData)


def _path() -> str:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "NuFlow")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "vault.json")


def set_secret(name: str, value: str) -> None:
    data = _load_raw()
    data[name] = _encrypt(value)
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_secret(name: str) -> str:
    enc = _load_raw().get(name, "")
    return _decrypt(enc) if enc else ""


def list_secrets() -> list[str]:
    return sorted(_load_raw().keys())


def _load_raw() -> dict:
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}
