"""
NuFlow — motor de orquestração de fluxos (RPA + IA).

Um Flow é uma sequência declarativa de Steps. Cada step chama uma "action"
registrada (ver steps.py) que lê/escreve no `context` compartilhado. O runner
cuida de: templating de parâmetros ({{var}}), retry com backoff, captura de
erro, logging estruturado e (para steps de UI) screenshot em falha.

Tudo em stdlib — sem dependência obrigatória. Steps que precisam de extras
(xlsx, Claude, automação de UI) falham com mensagem clara orientando a instalar.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

LogFn = Callable[[str, str], None]  # (nivel, mensagem)

_TEMPLATE_RE = re.compile(r"\{\{\s*([\w.]+)\s*\}\}")


def _default_log(level: str, msg: str) -> None:
    print(f"[{level}] {msg}")


@dataclass
class Step:
    action: str
    params: dict = field(default_factory=dict)
    id: str = ""
    retries: int = 0
    backoff: float = 1.0
    on_error: str = "stop"        # 'stop' | 'continue'
    when: dict | None = None      # condição opcional {left, op, right}


@dataclass
class Flow:
    name: str
    steps: list[Step] = field(default_factory=list)
    vars: dict = field(default_factory=dict)

    @staticmethod
    def from_dict(d: dict) -> "Flow":
        steps = []
        for raw in d.get("steps", []):
            steps.append(Step(
                action=raw["action"], params=raw.get("params", {}),
                id=raw.get("id", ""), retries=int(raw.get("retries", 0)),
                backoff=float(raw.get("backoff", 1.0)),
                on_error=raw.get("on_error", "stop"), when=raw.get("when")))
        return Flow(name=d.get("name", "flow"), steps=steps, vars=d.get("vars", {}))


@dataclass
class StepResult:
    index: int
    action: str
    id: str
    status: str                  # 'ok' | 'erro' | 'pulado'
    duration_ms: int = 0
    error: str = ""
    attempts: int = 1


@dataclass
class RunResult:
    flow: str
    status: str = "ok"           # 'ok' | 'erro'
    steps: list[StepResult] = field(default_factory=list)
    context: dict = field(default_factory=dict)
    duration_ms: int = 0

    @property
    def ok_count(self) -> int:
        return sum(1 for s in self.steps if s.status == "ok")

    @property
    def err_count(self) -> int:
        return sum(1 for s in self.steps if s.status == "erro")


def _resolve(value: Any, ctx: dict) -> Any:
    """Substitui {{var}} (com caminho a.b) em strings; recursivo em dict/list."""
    if isinstance(value, str):
        def repl(m):
            path = m.group(1).split(".")
            cur: Any = ctx
            for p in path:
                if isinstance(cur, dict) and p in cur:
                    cur = cur[p]
                else:
                    return m.group(0)
            return str(cur)
        # se a string é só "{{x}}", devolve o objeto cru (não string)
        whole = _TEMPLATE_RE.fullmatch(value.strip())
        if whole:
            path = whole.group(1).split(".")
            cur = ctx
            for p in path:
                if isinstance(cur, dict) and p in cur:
                    cur = cur[p]
                else:
                    return value
            return cur
        return _TEMPLATE_RE.sub(repl, value)
    if isinstance(value, dict):
        return {k: _resolve(v, ctx) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve(v, ctx) for v in value]
    return value


def _check_when(when: dict, ctx: dict) -> bool:
    left = _resolve(when.get("left"), ctx)
    right = _resolve(when.get("right"), ctx)
    op = when.get("op", "==")
    try:
        if op == "==":
            return left == right
        if op == "!=":
            return left != right
        if op == ">":
            return float(left) > float(right)
        if op == "<":
            return float(left) < float(right)
        if op == "exists":
            return left is not None
        if op == "not_empty":
            return bool(left)
    except (TypeError, ValueError):
        return False
    return False


class FlowRunner:
    def __init__(self, actions: dict[str, Callable], log: LogFn | None = None,
                 step_cb: Callable[[StepResult], None] | None = None):
        self.actions = actions
        self.log = log or _default_log
        self.step_cb = step_cb

    def run(self, flow: Flow, context: dict | None = None) -> RunResult:
        ctx = dict(flow.vars)
        if context:
            ctx.update(context)
        result = RunResult(flow=flow.name, context=ctx)
        t0 = time.monotonic()
        self.log("INFO", f"Iniciando fluxo '{flow.name}' ({len(flow.steps)} passos)")

        for i, step in enumerate(flow.steps):
            label = step.id or step.action
            sr = StepResult(index=i, action=step.action, id=step.id, status="ok")
            st = time.monotonic()

            if step.when is not None and not _check_when(step.when, ctx):
                sr.status = "pulado"
                self.log("INFO", f"[{i+1}/{len(flow.steps)}] {label}: pulado (condição falsa)")
                self._emit(sr, st)
                result.steps.append(sr)
                continue

            fn = self.actions.get(step.action)
            if fn is None:
                sr.status = "erro"
                sr.error = f"ação desconhecida: {step.action}"
                self.log("ERRO", sr.error)
                result.steps.append(self._emit(sr, st))
                if step.on_error == "stop":
                    result.status = "erro"
                    break
                continue

            attempt = 0
            while True:
                attempt += 1
                sr.attempts = attempt
                try:
                    params = _resolve(step.params, ctx)
                    self.log("INFO", f"[{i+1}/{len(flow.steps)}] {label}"
                                     + (f" (tentativa {attempt})" if attempt > 1 else ""))
                    fn(ctx, params, self.log)
                    sr.status = "ok"
                    break
                except Exception as e:  # noqa: BLE001
                    sr.error = f"{type(e).__name__}: {e}"
                    if attempt <= step.retries:
                        self.log("AVISO", f"{label} falhou ({sr.error}); retry em "
                                          f"{step.backoff}s")
                        time.sleep(step.backoff)
                        continue
                    sr.status = "erro"
                    self.log("ERRO", f"{label}: {sr.error}")
                    break

            result.steps.append(self._emit(sr, st))
            if sr.status == "erro" and step.on_error == "stop":
                result.status = "erro"
                break

        result.duration_ms = int((time.monotonic() - t0) * 1000)
        self.log("SUCESSO" if result.status == "ok" else "ERRO",
                 f"Fluxo '{flow.name}' finalizado: {result.ok_count} ok, "
                 f"{result.err_count} erro(s), {result.duration_ms} ms")
        return result

    def _emit(self, sr: StepResult, start: float) -> StepResult:
        sr.duration_ms = int((time.monotonic() - start) * 1000)
        if self.step_cb:
            self.step_cb(sr)
        return sr
