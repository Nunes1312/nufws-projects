"""
NuFlow — IDP (Intelligent Document Processing) com Claude.

Lê um documento (PDF ou imagem) e extrai os campos pedidos como JSON estruturado,
usando a API do Claude (visão/documento). É a peça de maior valor e menor
fragilidade da automação: "a IA lê o documento".

Requer o pacote `anthropic` e a variável ANTHROPIC_API_KEY (ou api_key explícita).
"""
from __future__ import annotations

import base64
import json
import os

DEFAULT_MODEL = "claude-opus-4-8"

_MEDIA = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg",
          ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}

SYSTEM = """Você é um extrator de dados de documentos (IDP). Recebe um documento e
uma lista de campos. Extraia SOMENTE os valores presentes no documento e responda
APENAS com um objeto JSON {campo: valor}. Use null quando o campo não existir.
Não invente dados. Datas em ISO (YYYY-MM-DD) quando possível; valores monetários
como número."""


def extract_document(path: str, fields: list[str], api_key: str | None = None,
                     instruction: str = "", model: str = DEFAULT_MODEL) -> dict:
    try:
        import anthropic
    except ImportError:
        raise RuntimeError("idp_extract requer o pacote 'anthropic' (pip install anthropic)")
    key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("ANTHROPIC_API_KEY não definida")
    if not os.path.isfile(path):
        raise RuntimeError(f"arquivo não encontrado: {path}")

    ext = os.path.splitext(path)[1].lower()
    media = _MEDIA.get(ext)
    if not media:
        raise RuntimeError(f"tipo não suportado: {ext} (use pdf/png/jpg)")

    with open(path, "rb") as f:
        b64 = base64.standard_b64encode(f.read()).decode("ascii")
    block_type = "document" if ext == ".pdf" else "image"

    fields_txt = ", ".join(fields) if fields else "todos os campos relevantes"
    prompt = (f"Extraia os seguintes campos: {fields_txt}."
              + (f"\nInstruções extras: {instruction}" if instruction else "")
              + "\nResponda só com o JSON.")

    client = anthropic.Anthropic(api_key=key)
    resp = client.messages.create(
        model=model, max_tokens=1500, system=SYSTEM,
        messages=[{"role": "user", "content": [
            {"type": block_type, "source": {"type": "base64", "media_type": media,
                                            "data": b64}},
            {"type": "text", "text": prompt}]}])
    text = "".join(b.text for b in resp.content if b.type == "text").strip()
    return _parse_json(text)


def _parse_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text[:4].lower() == "json":
            text = text[4:]
    s, e = text.find("{"), text.rfind("}")
    if s != -1 and e != -1 and e > s:
        try:
            return json.loads(text[s:e + 1])
        except json.JSONDecodeError:
            pass
    return {"_raw": text}
