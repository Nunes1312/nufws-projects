"""
NuFlow — biblioteca de ações (steps) e conectores.

Cada ação tem assinatura `fn(ctx: dict, params: dict, log) -> None` e lê/escreve
em `ctx`. Ações que dependem de extras (xlsx, Claude, automação de UI) importam
o pacote dentro da função e dão uma mensagem clara se faltar.

Convenção: a maioria das ações grava o resultado em ctx[params['into']].
"""
from __future__ import annotations

import csv
import json
import os
import urllib.request

ACTIONS: dict = {}


def action(name):
    def deco(fn):
        ACTIONS[name] = fn
        return fn
    return deco


# --------------------------------------------------------------- básicas
@action("log")
def _log(ctx, params, log):
    log(params.get("level", "INFO"), str(params.get("message", "")))


@action("set")
def _set(ctx, params, log):
    for k, v in params.get("vars", {}).items():
        ctx[k] = v
    log("INFO", f"variáveis definidas: {list(params.get('vars', {}))}")


@action("condition")
def _condition(ctx, params, log):
    # apenas grava um booleano em `into` (ramificação real usa 'when' nos steps)
    from .flow import _check_when
    ctx[params.get("into", "cond")] = _check_when(params, ctx)


# --------------------------------------------------------------- arquivos / dados
@action("read_csv")
def _read_csv(ctx, params, log):
    path = params["path"]
    delim = params.get("delimiter", ",")
    with open(path, "r", encoding=params.get("encoding", "utf-8-sig"), newline="") as f:
        rows = list(csv.DictReader(f, delimiter=delim))
    ctx[params.get("into", "data")] = rows
    log("SUCESSO", f"lidas {len(rows)} linha(s) de {os.path.basename(path)}")


@action("write_csv")
def _write_csv(ctx, params, log):
    data = _dataset(ctx, params)
    path = params["path"]
    if not data:
        log("AVISO", "dataset vazio; nada a escrever")
        open(path, "w").close()
        return
    fields = params.get("columns") or list(data[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(data)
    log("SUCESSO", f"{len(data)} linha(s) escritas em {os.path.basename(path)}")


@action("write_xlsx")
def _write_xlsx(ctx, params, log):
    try:
        from openpyxl import Workbook
    except ImportError:
        raise RuntimeError("write_xlsx requer openpyxl: pip install openpyxl")
    data = _dataset(ctx, params)
    wb = Workbook()
    ws = wb.active
    ws.title = params.get("sheet", "Dados")
    if data:
        fields = params.get("columns") or list(data[0].keys())
        ws.append(fields)
        for row in data:
            ws.append([row.get(c, "") for c in fields])
    wb.save(params["path"])
    log("SUCESSO", f"{len(data)} linha(s) em {os.path.basename(params['path'])}")


@action("transform")
def _transform(ctx, params, log):
    """Seleciona/renomeia/filtra colunas (declarativo, sem eval)."""
    data = _dataset(ctx, params)
    select = params.get("select")          # lista de colunas a manter
    rename = params.get("rename", {})       # {de: para}
    out = []
    for row in data:
        r = dict(row)
        if select:
            r = {k: r.get(k) for k in select}
        for de, para in rename.items():
            if de in r:
                r[para] = r.pop(de)
        out.append(r)
    ctx[params.get("into", "data")] = out
    log("INFO", f"transform: {len(out)} linha(s)")


# --------------------------------------------------------------- HTTP
@action("http_get")
def _http_get(ctx, params, log):
    url = params["url"]
    req = urllib.request.Request(url, headers=params.get("headers", {
        "User-Agent": "NuFlow/0.1", "Accept": "application/json"}))
    with urllib.request.urlopen(req, timeout=params.get("timeout", 20)) as resp:  # noqa: S310
        body = resp.read().decode("utf-8", "replace")
    try:
        ctx[params.get("into", "response")] = json.loads(body)
    except json.JSONDecodeError:
        ctx[params.get("into", "response")] = body
    log("SUCESSO", f"GET {url} ok")


# --------------------------------------------------------------- reconciliação
@action("reconcile")
def _reconcile(ctx, params, log):
    """Compara dois datasets por chave → só_em_A, só_em_B, divergentes."""
    a = ctx.get(params["a"], [])
    b = ctx.get(params["b"], [])
    key = params["key"]
    compare = params.get("compare")  # colunas a comparar; None = todas comuns
    idx_a = {str(r.get(key)): r for r in a}
    idx_b = {str(r.get(key)): r for r in b}
    only_a = [idx_a[k] for k in idx_a.keys() - idx_b.keys()]
    only_b = [idx_b[k] for k in idx_b.keys() - idx_a.keys()]
    mismatched = []
    for k in idx_a.keys() & idx_b.keys():
        ra, rb = idx_a[k], idx_b[k]
        cols = compare or (set(ra) & set(rb)) - {key}
        diffs = {c: {"a": ra.get(c), "b": rb.get(c)} for c in cols
                 if str(ra.get(c)) != str(rb.get(c))}
        if diffs:
            mismatched.append({key: k, "diffs": diffs})
    report = {"only_in_a": only_a, "only_in_b": only_b, "mismatched": mismatched,
              "matched": len(idx_a.keys() & idx_b.keys()) - len(mismatched)}
    ctx[params.get("into", "reconciliation")] = report
    log("SUCESSO", f"reconcile: {len(only_a)} só-A, {len(only_b)} só-B, "
                   f"{len(mismatched)} divergente(s), {report['matched']} ok")


# --------------------------------------------------------------- IDP (Claude)
@action("idp_extract")
def _idp_extract(ctx, params, log):
    from .idp import extract_document
    fields = params.get("fields", [])
    result = extract_document(params["path"], fields,
                              api_key=params.get("api_key"),
                              instruction=params.get("instruction", ""))
    ctx[params.get("into", "document")] = result
    log("SUCESSO", f"IDP extraiu {len(result)} campo(s) de "
                   f"{os.path.basename(params['path'])}")


# --------------------------------------------------------------- automação de UI
@action("ui_action")
def _ui_action(ctx, params, log):
    """
    Automação de UI (integração de legado sem API). Requer pywinauto/pyautogui.
    op: launch | focus | click | type | screenshot
    """
    op = params.get("op")
    try:
        if op in ("type", "click_xy", "hotkey", "screenshot_full"):
            import pyautogui  # noqa: F401
        if op in ("launch", "focus", "click"):
            from pywinauto import Application  # noqa: F401
    except ImportError:
        raise RuntimeError("automação de UI requer: pip install pywinauto pyautogui")
    from . import ui_automation as uia
    uia.run(op, params, log)


# --------------------------------------------------------------- helpers
def _dataset(ctx, params):
    """Resolve o dataset de entrada: params['data'] (nome no ctx) ou lista direta."""
    src = params.get("data", "data")
    if isinstance(src, list):
        return src
    val = ctx.get(src, [])
    return val if isinstance(val, list) else []
