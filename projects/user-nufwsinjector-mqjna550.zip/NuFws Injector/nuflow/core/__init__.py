"""Core do NuFlow: motor de fluxos, steps, triggers e vault."""
import json

from .flow import Flow, FlowRunner, RunResult, Step, StepResult
from .steps import ACTIONS


def load_flow(path: str) -> Flow:
    with open(path, "r", encoding="utf-8") as f:
        return Flow.from_dict(json.load(f))


def make_runner(log=None, step_cb=None) -> FlowRunner:
    return FlowRunner(ACTIONS, log=log, step_cb=step_cb)


__all__ = ["Flow", "FlowRunner", "RunResult", "Step", "StepResult", "ACTIONS",
           "load_flow", "make_runner"]
