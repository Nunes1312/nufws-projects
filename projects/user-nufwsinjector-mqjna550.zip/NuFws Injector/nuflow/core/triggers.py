"""
NuFlow — gatilhos (triggers): watcher de pasta e agendador por intervalo.

Sem dependência: o watcher usa polling (varre a pasta e compara mtime/conjunto
de arquivos). Roda numa thread daemon e chama o callback com o caminho do arquivo
novo/alterado. O scheduler dispara um callback a cada N segundos.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Callable


class FolderWatcher:
    """Observa uma pasta e dispara on_file(path) para arquivos novos/alterados."""

    def __init__(self, folder: str, on_file: Callable[[str], None],
                 patterns: tuple[str, ...] = (), interval: float = 2.0,
                 process_existing: bool = False):
        self.folder = folder
        self.on_file = on_file
        self.patterns = tuple(p.lower() for p in patterns)
        self.interval = interval
        self._seen: dict[str, float] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._process_existing = process_existing

    def _match(self, name: str) -> bool:
        return not self.patterns or name.lower().endswith(self.patterns)

    def _scan(self):
        try:
            entries = list(os.scandir(self.folder))
        except OSError:
            return []
        hits = []
        for e in entries:
            if not e.is_file() or not self._match(e.name):
                continue
            try:
                mtime = e.stat().st_mtime
            except OSError:
                continue
            prev = self._seen.get(e.path)
            if prev is None or mtime > prev:
                self._seen[e.path] = mtime
                hits.append(e.path)
        return hits

    def start(self):
        os.makedirs(self.folder, exist_ok=True)
        if not self._process_existing:
            self._scan()  # marca os existentes como já vistos
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        while not self._stop.is_set():
            for path in self._scan():
                try:
                    self.on_file(path)
                except Exception:  # noqa: BLE001
                    pass
            self._stop.wait(self.interval)

    def stop(self):
        self._stop.set()


class IntervalScheduler:
    """Dispara on_tick() a cada `seconds`."""

    def __init__(self, seconds: float, on_tick: Callable[[], None]):
        self.seconds = max(1.0, seconds)
        self.on_tick = on_tick
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        while not self._stop.is_set():
            if self._stop.wait(self.seconds):
                break
            try:
                self.on_tick()
            except Exception:  # noqa: BLE001
                pass

    def stop(self):
        self._stop.set()
