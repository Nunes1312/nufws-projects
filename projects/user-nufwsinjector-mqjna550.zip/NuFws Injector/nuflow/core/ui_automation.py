"""
NuFlow — automação de UI (integração de legado SEM API).

Wrapper fino sobre pywinauto (controles Win32/UIA) e pyautogui (teclado/mouse/
screenshot). É como se integra um sistema que só expõe a tela. É a parte mais
PODEROSA e ao mesmo tempo mais FRÁGIL (quebra se a tela do app mudar) — use com
seletores estáveis (auto_id/título) e screenshots de auditoria.

Requer: pip install pywinauto pyautogui
"""
from __future__ import annotations

import os
import time

_apps: dict = {}  # cache de apps conectados por título


def run(op: str, params: dict, log) -> None:
    if op == "launch":
        _launch(params, log)
    elif op == "focus":
        _focus(params, log)
    elif op == "click":
        _click(params, log)
    elif op == "type":
        _type(params, log)
    elif op == "click_xy":
        _click_xy(params, log)
    elif op == "hotkey":
        _hotkey(params, log)
    elif op in ("screenshot", "screenshot_full"):
        _screenshot(params, log)
    elif op == "sleep":
        time.sleep(float(params.get("seconds", 1)))
    else:
        raise RuntimeError(f"op de UI desconhecida: {op}")


def _launch(params, log):
    from pywinauto import Application
    backend = params.get("backend", "uia")
    app = Application(backend=backend).start(params["cmd"])
    _apps[params.get("title", params["cmd"])] = app
    log("SUCESSO", f"app iniciado: {params['cmd']}")
    time.sleep(float(params.get("wait", 2)))


def _connect(params):
    from pywinauto import Application
    backend = params.get("backend", "uia")
    return Application(backend=backend).connect(
        title_re=params.get("title_re"), title=params.get("title"),
        timeout=float(params.get("timeout", 10)))


def _focus(params, log):
    app = _connect(params)
    win = app.top_window()
    win.set_focus()
    log("SUCESSO", f"janela em foco: {win.window_text()[:40]}")


def _click(params, log):
    app = _connect(params)
    win = app.top_window()
    ctrl = win.child_window(auto_id=params.get("auto_id"),
                            title=params.get("control"),
                            control_type=params.get("control_type"))
    ctrl.click_input()
    log("SUCESSO", f"clique em {params.get('auto_id') or params.get('control')}")


def _type(params, log):
    import pyautogui
    text = str(params.get("text", ""))
    interval = float(params.get("interval", 0.02))
    pyautogui.typewrite(text, interval=interval)
    if params.get("enter"):
        pyautogui.press("enter")
    log("SUCESSO", f"digitado {len(text)} caractere(s)")


def _click_xy(params, log):
    import pyautogui
    pyautogui.click(int(params["x"]), int(params["y"]))
    log("SUCESSO", f"clique em ({params['x']},{params['y']})")


def _hotkey(params, log):
    import pyautogui
    keys = params.get("keys", [])
    pyautogui.hotkey(*keys)
    log("SUCESSO", f"hotkey {'+'.join(keys)}")


def _screenshot(params, log):
    import pyautogui
    path = params.get("path") or os.path.join(
        os.environ.get("TEMP", "."), f"nuflow_shot_{int(time.time())}.png")
    pyautogui.screenshot(path)
    log("SUCESSO", f"screenshot salvo: {path}")
