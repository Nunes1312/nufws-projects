"""
Verificação local do NuFlow (zero dependência externa).

Cobre: motor de fluxo (templating, retry, condição), steps read_csv/reconcile/
transform/write_csv/http? (sem rede), vault DPAPI e o watcher de pasta.

Rode:  python -m tests.flow_localtest
"""
from __future__ import annotations

import os
import tempfile
import time

from nuflow.core import Flow, make_runner
from nuflow.core import vault
from nuflow.core.triggers import FolderWatcher

_fails = 0


def check(name, cond, extra=""):
    global _fails
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {extra}" if extra else ""))
    if not cond:
        _fails += 1


def main() -> int:
    tmp = tempfile.mkdtemp(prefix="nuflow_")
    a = os.path.join(tmp, "a.csv")
    b = os.path.join(tmp, "b.csv")
    open(a, "w", encoding="utf-8").write("id,nome,valor\n1,Alice,100\n2,Bruno,250\n4,Diego,400\n")
    open(b, "w", encoding="utf-8").write("id,nome,valor\n1,Alice,100\n2,Bruno,275\n5,Eva,75\n")

    logs = []
    runner = make_runner(log=lambda lvl, msg: logs.append((lvl, msg)))

    flow = Flow.from_dict({
        "name": "teste", "vars": {"dir": tmp},
        "steps": [
            {"action": "read_csv", "params": {"path": "{{dir}}/a.csv", "into": "A"}},
            {"action": "read_csv", "params": {"path": "{{dir}}/b.csv", "into": "B"}},
            {"action": "reconcile", "params": {"a": "A", "b": "B", "key": "id",
                                               "compare": ["valor"], "into": "rec"}},
            {"action": "transform", "params": {"data": "{{rec.only_in_a}}",
                                               "select": ["id", "nome"], "into": "saida"}},
            {"action": "write_csv", "params": {"data": "{{saida}}",
                                               "path": "{{dir}}/out.csv"}},
        ]})
    res = runner.run(flow)
    check("fluxo terminou ok", res.status == "ok", f"{res.ok_count} steps")

    rec = res.context["rec"]
    check("reconcile: 1 só-em-A (Diego)", len(rec["only_in_a"]) == 1 and
          rec["only_in_a"][0]["nome"] == "Diego")
    check("reconcile: 1 só-em-B (Eva)", len(rec["only_in_b"]) == 1)
    check("reconcile: 1 divergência (Bruno valor)", len(rec["mismatched"]) == 1 and
          rec["mismatched"][0]["id"] == "2")
    check("transform aplicou select", set(res.context["saida"][0].keys()) == {"id", "nome"})
    check("write_csv gerou arquivo", os.path.isfile(os.path.join(tmp, "out.csv")))
    check("templating {{dir}} resolveu", any("a.csv" not in m and "lidas" in m for _, m in logs))

    # retry + on_error
    flow2 = Flow.from_dict({"name": "retry", "steps": [
        {"action": "inexistente", "on_error": "continue"},
        {"action": "log", "params": {"message": "segui após erro"}},
    ]})
    res2 = runner.run(flow2)
    check("on_error=continue segue o fluxo", res2.steps[0].status == "erro" and
          res2.steps[1].status == "ok")

    # condição 'when'
    flow3 = Flow.from_dict({"name": "cond", "vars": {"x": 5}, "steps": [
        {"action": "log", "params": {"message": "não deve rodar"},
         "when": {"left": "{{x}}", "op": ">", "right": 10}},
        {"action": "log", "params": {"message": "deve rodar"},
         "when": {"left": "{{x}}", "op": "<", "right": 10}},
    ]})
    res3 = runner.run(flow3)
    check("when pula/roda corretamente", res3.steps[0].status == "pulado" and
          res3.steps[1].status == "ok")

    # vault DPAPI
    vault.set_secret("teste_legado_pw", "S3nh@!")
    got = vault.get_secret("teste_legado_pw")
    check("vault DPAPI round-trip", got == "S3nh@!")
    raw = open(vault._path(), encoding="utf-8").read()
    check("segredo NÃO em texto puro", "S3nh@!" not in raw)

    # watcher de pasta
    seen = []
    w = FolderWatcher(tmp, on_file=lambda p: seen.append(p), patterns=(".trigger",),
                      interval=0.3)
    w.start()
    time.sleep(0.5)
    open(os.path.join(tmp, "novo.trigger"), "w").write("x")
    time.sleep(0.8)
    w.stop()
    check("watcher detectou arquivo novo", any(p.endswith("novo.trigger") for p in seen))

    print("RESULTADO:", "TODOS PASS" if not _fails else f"{_fails} FALHA(S)")
    return 1 if _fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
