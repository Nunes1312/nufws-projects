# NuFlow — Hiperautomação & Orquestração de Processos (v0.1)

RPA + IA para automatizar processos repetitivos: **ler documentos** (IDP com Claude),
**integrar sistemas legados sem API** (automação de UI) e **orquestrar fluxos** com
retry, gatilhos e auditoria. Produto irmão do NuFws Injector (reaproveita os padrões:
Claude, DPAPI, PyQt, Workers), mas **separado** — público e perfil de confiança diferentes.

> **v0.1 é uma fundação funcional, não um produto final.** O motor, os steps de dados,
> a reconciliação, o cofre e o watcher estão prontos e testados. IDP, automação de UI e
> xlsx funcionam com os extras instalados. Veja o roadmap no fim.

## Pilares

| Pilar | Estado | Como |
|-------|--------|------|
| **Orquestrador** | ✅ pronto | `nuflow/core/flow.py` — fluxos JSON, retry/backoff, `when`, templating `{{var}}`, log/auditoria por step |
| **Dados / Integração** | ✅ pronto | steps `read_csv`/`write_csv`/`transform`/`http_get`/`reconcile` (stdlib) |
| **Reconciliação/validação** | ✅ pronto | step `reconcile` → só-em-A / só-em-B / divergentes |
| **Cofre de credenciais** | ✅ pronto | `vault.py` (Windows DPAPI), para logins de sistemas legados |
| **Gatilhos** | ✅ pronto | `triggers.py` — watcher de pasta (polling) + agendador por intervalo |
| **IDP (ler documentos)** | ⚙️ requer `anthropic` + key | `idp.py` — PDF/imagem → JSON via Claude (visão) |
| **Automação de UI (legado)** | ⚙️ requer `pywinauto`/`pyautogui` | `ui_automation.py` — launch/focus/click/type/screenshot |
| **xlsx** | ⚙️ requer `openpyxl` | step `write_xlsx` |

## Uso

```powershell
pip install -r requirements.txt   # PyQt6 obrigatório; resto é opcional
python run.py                     # abre a UI (Fluxos · Documentos IDP · Cofre)
```

Headless / agendado (Agendador de Tarefas, CI):
```powershell
python -m nuflow.cli flows\reconciliacao.json --dir flows
```

## Exemplo de fluxo (JSON)

`flows/reconciliacao.json` lê dois CSVs de sistemas distintos, reconcilia por `id`,
loga o resumo e exporta as diferenças. Um step é:

```json
{"id": "reconciliar", "action": "reconcile",
 "params": {"a": "sistema_a", "b": "sistema_b", "key": "id",
            "compare": ["valor"], "into": "recon"}}
```

Steps disponíveis: `log`, `set`, `condition`, `read_csv`, `write_csv`, `write_xlsx`,
`transform`, `http_get`, `reconcile`, `idp_extract`, `ui_action`.

## Testes

```powershell
python -m tests.flow_localtest   # motor, steps, reconcile, vault, watcher (zero-dep)
```

## O lado honesto (sem hype)

- RPA **economiza horas de verdade** em processos **repetitivos, baseados em regras,
  de alto volume** — o valor está em escolher o processo certo.
- Automação de UI / screen-scraping para "legado sem API" **funciona mas é frágil**
  (quebra se a tela muda). IA/OCR reduz, não elimina. Exige manutenção e seletores estáveis.
- O pedaço de maior valor e menor fragilidade é o **IDP** (a IA lendo documentos).

## Roadmap (próximas fases)

1. **IDP+OCR** para PDFs digitalizados (Tesseract) e validação de campos por regras.
2. **Editor visual de fluxos** (arrastar steps) e biblioteca de templates.
3. **Conectores**: e-mail (IMAP/SMTP), Excel avançado, banco de dados, Selenium/Playwright (legado web), terminal/telnet (telas verdes).
4. **Orquestração não-assistida**: filas de trabalho, execução paralela, recuperação, human-in-the-loop, screenshots de auditoria.
5. **Governança/ROI**: trilha transacional, dashboard de horas economizadas e erros evitados, alertas.
6. **Empacotamento**: instalador próprio (como o NuFws), serviço de agendamento.

## Arquitetura

```
nuflow/
  core/  flow.py · steps.py · idp.py · ui_automation.py · triggers.py · vault.py
  ui/    theme.py · app.py
  main.py · cli.py
flows/   reconciliacao.json + CSVs de exemplo
tests/   flow_localtest.py
```
